const currency = [
  {
    name: "Euro",
    symbol: "€",
    status: "show",
  },
  {
    name: "Dollar",
    symbol: "$",
    status: "show",
  },
  {
    name: "Pound",
    symbol: "£",
    status: "show",
  },
];

module.exports = currency;
